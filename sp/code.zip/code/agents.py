"""
agents.py
---------
The three agents of the Meeting Intelligence System.

Design rules (NON-NEGOTIABLE):
  • Every agent uses BOTH an LLM AND tools.
  • Agents only read/write state — no agent calls another agent.
  • No tool controls routing.
  • Routing decisions are made by the LLM inside Input Validation Agent,
    then deterministically encoded in state.validation_status.
  • Graph routing reads that status field — the LLM never routes implicitly.
"""

import json
from typing import Any, Dict

from langchain_core.messages import HumanMessage, SystemMessage

from config import get_llm
from state import MeetingState
from tools import (
    llm_tool,                      # ✅ REQUIRED
    word_count_tool,
    text_hash_tool,
    transcript_normalization_tool,
    extraction_tool,
    json_parse_tool,
    state_builder_tool,
    context_construction_tool,
    response_generation_tool,
)

# ══════════════════════════════════════════════════════════════════
# 1. INPUT VALIDATION AGENT
# ══════════════════════════════════════════════════════════════════
def input_validation_agent(state: MeetingState) -> MeetingState:
    """
    Entry-point decision-maker.
    """

    user_input = (state.get("user_input") or "").strip()

    # ─────────────────────────────────────────────
    # Hard guards (no LLM needed)
    # ─────────────────────────────────────────────
    if not user_input:
        state["validation_status"] = "invalid"
        state["validation_reason"] = "Empty input."
        state["response"] = response_generation_tool.invoke({
            "reason": "The message was empty.",
            "input_type": "invalid",
        })
        return state

    if word_count_tool.invoke({"text": user_input}) < 3:
        state["validation_status"] = "invalid"
        state["validation_reason"] = "Input too short."
        state["response"] = response_generation_tool.invoke({
            "reason": "The input was too short.",
            "input_type": "too_short",
        })
        return state

    # ─────────────────────────────────────────────
    # LLM-based semantic classification
    # ─────────────────────────────────────────────
    classification_prompt = f"""
You are a strict input classification system.

Classify the USER INPUT into EXACTLY ONE of:
- greeting
- invalid
- new_transcript
- question

Respond ONLY with valid JSON.

Schema:
{{
  "classification": "greeting | invalid | new_transcript | question",
  "reason": "<short explanation>"
}}

USER INPUT:
\"\"\"{user_input}\"\"\"
"""

    raw = llm_tool.invoke({"prompt": classification_prompt})

    try:
        parsed = json.loads(raw)
        classification = parsed.get("classification", "").strip()
        reason = parsed.get("reason", "").strip()
    except Exception:
        classification = "invalid"
        reason = "Failed to parse LLM response."

    # ─────────────────────────────────────────────
    # Deterministic post-processing
    # ─────────────────────────────────────────────
    if classification == "greeting":
        state["validation_status"] = "greeting"
        state["validation_reason"] = reason
        state["response"] = response_generation_tool.invoke({
            "reason": reason,
            "input_type": "greeting",
        })
        return state

    if classification == "invalid":
        state["validation_status"] = "invalid"
        state["validation_reason"] = reason
        state["response"] = response_generation_tool.invoke({
            "reason": reason,
            "input_type": "invalid",
        })
        return state

    if classification == "question":
        if state.get("extraction_complete"):
            state["validation_status"] = "valid_existing"
            state["validation_reason"] = "Question about processed transcript."
            return state

        state["validation_status"] = "invalid"
        state["validation_reason"] = "Question asked before transcript ingestion."
        state["response"] = response_generation_tool.invoke({
            "reason": "No transcript has been processed yet.",
            "input_type": "invalid",
        })
        return state

    if classification == "new_transcript":
        normalized = transcript_normalization_tool.invoke({"raw_text": user_input})
        transcript_hash = text_hash_tool.invoke({"text": normalized})

        if transcript_hash == state.get("transcript_hash"):
            state["validation_status"] = "duplicate"
            state["validation_reason"] = "Duplicate transcript."
            return state

        state["validation_status"] = "valid_new"
        state["validation_reason"] = "New transcript accepted."
        state["transcript"] = normalized
        state["transcript_hash"] = transcript_hash
        return state

    state["validation_status"] = "invalid"
    state["validation_reason"] = "Unrecognized classification."
    state["response"] = response_generation_tool.invoke({
        "reason": "Unable to classify the input.",
        "input_type": "invalid",
    })
    return state

# ══════════════════════════════════════════════════════════════════
# 2. TRANSCRIPT PROCESSING AGENT
# ══════════════════════════════════════════════════════════════════
def transcript_processing_agent(state: MeetingState) -> MeetingState:
    """
    Knowledge extraction & preparation agent.
    """

    transcript = state.get("transcript", "")
    llm = get_llm()

    raw_json = extraction_tool.invoke({"transcript": transcript})
    validated = json_parse_tool.invoke({"raw_json": raw_json})
    payload_str = state_builder_tool.invoke({"validated_json": validated})

    try:
        payload = json.loads(payload_str)
    except Exception:
        payload = {"extraction_complete": False, "error": "Invalid state payload"}

    audit_note = (
        llm.invoke(
            f"Briefly confirm extraction quality:\n{payload_str[:800]}"
        ).content.strip()
        if payload.get("extraction_complete")
        else f"Extraction failed: {payload.get('error')}"
    )

    return {
        **state,
        "summary": payload.get("summary"),
        "action_items": payload.get("action_items"),
        "decisions": payload.get("decisions"),
        "key_topics": payload.get("key_topics"),
        "extraction_complete": payload.get("extraction_complete", False),
        "validation_reason": f"{state.get('validation_reason','')} | Audit: {audit_note}",
    }


# ══════════════════════════════════════════════════════════════════
# 3. QA AGENT
# ══════════════════════════════════════════════════════════════════
def qa_agent(state: MeetingState) -> MeetingState:
    """
    Knowledge-grounded reasoning agent.
    """

    llm = get_llm()

    context = context_construction_tool.invoke({
        "summary":      state.get("summary") or "",
        "action_items": json.dumps(state.get("action_items") or []),
        "decisions":    json.dumps(state.get("decisions") or []),
        "key_topics":   json.dumps(state.get("key_topics") or []),
    })

    system_prompt = """You are the QA Agent.
Answer ONLY from the provided context.
If the answer is missing, say so explicitly."""

    user_prompt = f"""{context}

USER QUESTION:
{state.get("user_input","")}"""

    answer = llm.invoke([
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_prompt),
    ])

    return {
        **state,
        "response": answer.content.strip(),
    }