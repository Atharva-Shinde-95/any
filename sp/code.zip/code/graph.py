"""
graph.py

LangGraph graph definition for the Meeting Intelligence System.

Control flow (deterministic — driven ONLY by state.validation_status):

START
↓
input_validation
├─ "greeting"        → END
├─ "invalid"         → END
├─ "duplicate"       → qa → END
├─ "valid_existing"  → qa → END
└─ "valid_new"       → transcript_processing → qa → END

Routing is a pure Python function reading state.validation_status.
The LLM never decides routing implicitly.
"""

from langgraph.graph import StateGraph, END
from state import MeetingState
from agents import (
    input_validation_agent,
    transcript_processing_agent,
    qa_agent,
)

# ─────────────────────────────────────────────
# Deterministic router — reads state only
# ─────────────────────────────────────────────

def route_after_validation(state: MeetingState) -> str:
    """
    Pure routing function. No LLM. No side effects.
    Returns the name of the next node (or END sentinel).
    """
    return state.get("validation_status", "invalid")

# ─────────────────────────────────────────────
# Graph construction
# ─────────────────────────────────────────────

def build_graph():
    graph = StateGraph(MeetingState)

    # ── Nodes ─────────────────────────────────
    graph.add_node("input_validation", input_validation_agent)
    graph.add_node("transcript_processing", transcript_processing_agent)
    graph.add_node("qa", qa_agent)

    # ── Entry point ───────────────────────────
    graph.set_entry_point("input_validation")

    # ── Conditional routing after validation ──
    graph.add_conditional_edges(
        "input_validation",
        route_after_validation,
        {
            "greeting": END,
            "invalid": END,
            "duplicate": "qa",
            "valid_existing": "qa",
            "valid_new": "transcript_processing",
        },
    )

    # ── Linear edges ──────────────────────────
    graph.add_edge("transcript_processing", "qa")
    graph.add_edge("qa", END)

    # ── Compile ───────────────────────────────
    return graph.compile()


# ─────────────────────────────────────────────
# Compiled graph — imported by app.py
# ─────────────────────────────────────────────

meeting_graph = build_graph()