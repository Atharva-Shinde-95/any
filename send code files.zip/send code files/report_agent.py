# agents/report_agent.py
"""
Report Agent — generates a rich Markdown table and a Plotly Gantt chart
that match the expected production-planner output style.
"""
import os
import pandas as pd
import plotly.graph_objects as go
from graph.state import PlanningState
from config.settings import OUTPUT_DIR


def report_node(state: PlanningState) -> PlanningState:
    schedule_df = state.get("schedule_df")
    if schedule_df is None or schedule_df.empty:
        return {**state, "error": "No schedule available to report."}

    try:
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        print(f"[REPORT] Schedule data: {len(schedule_df)} rows")

        # ── Markdown table ─────────────────────────────────────────────────────
        print("[REPORT] Generating Markdown table...")
        table_str = _format_schedule_table(schedule_df)
        print(f"[REPORT] Table generated ({len(table_str)} chars)")

        # ── Gantt chart ────────────────────────────────────────────────────────
        print("[REPORT] Generating Gantt chart...")
        gantt_path = _generate_gantt_chart(schedule_df, OUTPUT_DIR, "production_gantt")
        print(f"[REPORT] Gantt chart saved: {gantt_path}")

        # ── Planner insights summary ───────────────────────────────────────────
        insights = _build_insights(schedule_df, state)

        return {
            **state,
            "table_str":  table_str,
            "gantt_path": gantt_path,
            "insights":   insights,
        }

    except Exception as e:
        import traceback
        traceback.print_exc()
        return {**state, "error": f"Report generation failed: {str(e)}"}


# ── Markdown table ─────────────────────────────────────────────────────────────

def _format_schedule_table(df: pd.DataFrame) -> str:
    """
    Render schedule as a Markdown table.
    Preferred column order matches the expected planner output.
    """
    preferred = [
        "Sequence", "Task", "Resource",
        "Priority", "Service_Level", "Delivery_Date",
        "Quantity", "Start", "Finish", "Duration", "Slack_Days",
    ]
    # Fall back gracefully: include any column that actually exists
    cols = [c for c in preferred if c in df.columns]
    if not cols:
        cols = list(df.columns)

    df_out = df[cols].copy()

    # Pretty-print numeric columns
    for col in ["Start", "Finish", "Duration"]:
        if col in df_out.columns:
            df_out[col] = df_out[col].apply(
                lambda v: f"Day {int(v)}" if str(v).lstrip("-").isdigit() else v
            )

    # Pretty-print slack: positive → "✅ +N", negative → "🔴 -N", zero → "⚡ 0"
    if "Slack_Days" in df_out.columns:
        def _fmt_slack(v):
            if v == "" or pd.isna(v):
                return "—"
            v = int(v)
            if v > 0:
                return f"✅ +{v}"
            elif v < 0:
                return f"🔴 {v}"
            else:
                return "⚡ 0"
        df_out["Slack_Days"] = df_out["Slack_Days"].apply(_fmt_slack)

    header    = "| " + " | ".join(cols) + " |"
    separator = "|" + "|".join([" --- "] * len(cols)) + "|"
    rows = [
        "| " + " | ".join(str(df_out.iloc[i][c]) for c in cols) + " |"
        for i in range(len(df_out))
    ]
    return "\n".join([header, separator] + rows)


# ── Gantt chart ────────────────────────────────────────────────────────────────

# Colour palette: high-priority tasks get a darker shade
_PRIORITY_COLOURS = {
    "high":    "#1565C0",   # dark blue
    "urgent":  "#1565C0",
    "normal":  "#1E88E5",   # medium blue
    "medium":  "#1E88E5",
    "low":     "#90CAF9",   # light blue
    "":        "#1E88E5",
}


def _bar_colour(priority_str: str) -> str:
    return _PRIORITY_COLOURS.get(str(priority_str).strip().lower(), "#1E88E5")


def _generate_gantt_chart(df: pd.DataFrame, output_dir: str, filename: str) -> str:
    """
    Build a Plotly Gantt chart that mirrors the expected planner output:
      - Y-axis: SKU / Task names ordered bottom (first scheduled) → top (last scheduled)
      - X-axis: Day numbers
      - Colour intensity reflects priority (darker = higher priority)
      - Hover shows sequence, quantity, priority, service level
    """
    df = df.copy().reset_index(drop=True)

    # Ensure Start / Finish are integers
    for col in ("Start", "Finish"):
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(int)

    task_col = "Task" if "Task" in df.columns else df.columns[0]

    # Y-axis: tasks ordered so that sequence-1 is at BOTTOM (matches expected image)
    # Plotly yaxis with categoryorder='array' lets us control the order explicitly.
    y_order = df[task_col].tolist()[::-1]   # reverse so seq-1 appears at bottom

    fig = go.Figure()

    for _, row in df.iterrows():
        start  = row.get("Start",  0)
        finish = row.get("Finish", start)
        task   = row[task_col]
        prio   = str(row.get("Priority", ""))
        colour = _bar_colour(prio)

        hover_parts = [f"<b>{task}</b>"]
        if "Sequence"      in row: hover_parts.append(f"Sequence: {row['Sequence']}")
        if "Priority"      in row: hover_parts.append(f"Priority: {row['Priority']}")
        if "Service_Level" in row and row["Service_Level"] != "": hover_parts.append(f"Service Level: {row['Service_Level']}%")
        if "Quantity"      in row: hover_parts.append(f"Quantity: {row['Quantity']:,}")
        if "Delivery_Date" in row and row["Delivery_Date"] != "": hover_parts.append(f"Delivery Date: {row['Delivery_Date']}")
        hover_parts.append(f"Day {start} → Day {finish}")

        fig.add_trace(go.Bar(
            x         = [finish - start + 1],
            y         = [task],
            base      = [start - 1],           # bar starts at start-1 so Day 1 aligns with x=0
            orientation = "h",
            marker    = dict(color=colour, line=dict(color="white", width=1)),
            hovertemplate = "<br>".join(hover_parts) + "<extra></extra>",
            showlegend = False,
            name      = task,
        ))

    # X-axis ticks: every day from 1 to makespan
    makespan = int(df["Finish"].max()) if not df.empty else 10
    tickvals = list(range(0, makespan + 1))          # 0-based bar positions
    ticktext = [str(d + 1) for d in tickvals]        # label as Day 1, 2, …

    fig.update_layout(
        title=dict(
            text="Production Schedule Gantt Chart",
            font=dict(size=16, family="Arial"),
            x=0.5,
        ),
        barmode="overlay",
        xaxis=dict(
            title="Days",
            tickmode="array",
            tickvals=tickvals,
            ticktext=ticktext,
            showgrid=True,
            gridcolor="#e0e0e0",
            zeroline=False,
            # Force axis to show the full makespan range so no bars are clipped
            range=[-0.5, makespan + 0.5],
            fixedrange=False,
        ),
        yaxis=dict(
            title="SKU",
            categoryorder="array",
            categoryarray=y_order,
            showgrid=False,
        ),
        plot_bgcolor="white",
        paper_bgcolor="white",
        font=dict(family="Arial", size=12),
        # Do NOT set a fixed width — let the browser/Streamlit scale it
        autosize=True,
        height=max(400, len(df) * 60 + 180),
        margin=dict(l=130, r=60, t=70, b=70),
        hoverlabel=dict(bgcolor="white", font_size=12),
    )

    html_path = os.path.abspath(os.path.join(output_dir, filename + ".html"))
    fig.write_html(html_path, config={"responsive": True})
    return html_path


# ── Planner insights ───────────────────────────────────────────────────────────

def _build_insights(df: pd.DataFrame, state: dict) -> str:
    """Build a concise planner-insight text block."""
    lines = []

    makespan = state.get("makespan", int(df["Finish"].max()) if "Finish" in df.columns else "?")
    lines.append(f"**Total makespan:** {makespan} days")

    # Show schedule calendar range if start date is set
    start_date_str = state.get("schedule_start_date")
    if start_date_str:
        try:
            from datetime import datetime, timedelta
            base = datetime.strptime(start_date_str, "%Y-%m-%d")
            end_date = base + timedelta(days=int(makespan) - 1)
            lines.append(
                f"**Schedule period:** {base.strftime('%d-%b-%Y')} → "
                f"{end_date.strftime('%d-%b-%Y')}  _(Day 1 = {base.strftime('%d-%b-%Y')})_"
            )
        except (ValueError, TypeError):
            pass

    if "Priority" in df.columns:
        priority_counts = df["Priority"].value_counts().to_dict()
        lines.append("**Priority breakdown:** " +
                      ", ".join(f"{k}: {v}" for k, v in priority_counts.items()))

    if "Quantity" in df.columns:
        total_qty = int(df["Quantity"].sum())
        lines.append(f"**Total units scheduled:** {total_qty:,}")

    if "Resource" in df.columns:
        resources = df["Resource"].unique().tolist()
        lines.append(f"**Resources used:** {', '.join(resources)}")

    # Highlight any high-priority tasks
    if "Priority" in df.columns:
        high = df[df["Priority"].str.lower().isin(["high", "urgent", "critical"])]
        if not high.empty:
            lines.append(f"**High-priority SKUs scheduled first:** "
                         + ", ".join(high["Task"].tolist()))

    # Due-date validation: flag late deliveries
    if "Delivery_Date" in df.columns and "Finish" in df.columns:
        late_items = _check_due_dates(df, start_date_str)
        if late_items:
            lines.append("\n**📅 Delivery Date Analysis:**")
            for item in late_items:
                if item.get("is_warning"):
                    # This is the "no start date" warning
                    lines.append(f"- ⚠️ {item['status']}")
                else:
                    icon = "🔴" if "late" in item["status"].lower() else (
                           "🟡" if "tight" in item["status"].lower() else "✅")
                    date_info = ""
                    if item.get("finish_date_str"):
                        date_info = f" ({item['finish_date_str']})"
                    lines.append(
                        f"- {icon} **{item['task']}**: finishes Day {item['finish']}"
                        f"{date_info}, due {item['due_date']} — *{item['status']}*"
                    )
        else:
            if start_date_str:
                lines.append("**✅ All tasks scheduled within delivery deadlines.**")
            else:
                lines.append(
                    "**⚠️ Cannot verify delivery deadlines** — "
                    "set a schedule start date in the sidebar to enable calendar mapping."
                )

    return "\n\n".join(lines)


def _check_due_dates(df: pd.DataFrame, schedule_start_date: str | None) -> list:
    """
    Compare scheduled finish day against delivery dates.

    If schedule_start_date is provided (YYYY-MM-DD), converts Day N to a
    real calendar date:  actual_date = start_date + (N - 1) days.
    Then computes:  delay = actual_finish_date - due_date.

    If schedule_start_date is None, returns a warning that calendar mapping
    is not available — we do NOT guess or use today's date.
    """
    from datetime import datetime, timedelta

    date_formats = ["%Y-%m-%d", "%d-%m-%Y", "%m-%d-%Y",
                    "%d/%m/%Y", "%m/%d/%Y", "%d %b %Y", "%b %d %Y"]

    # ── Guard: no start date → cannot compute lateness ─────────────────────
    if not schedule_start_date:
        # Check if any delivery dates exist at all
        has_dates = False
        for _, row in df.iterrows():
            raw = str(row.get("Delivery_Date", "")).strip()
            if raw and raw.lower() not in ("", "none", "nan", "nat"):
                has_dates = True
                break
        if has_dates:
            return [{
                "task":       "—",
                "finish":     "—",
                "due_date":   "—",
                "status":     ("Cannot compute delivery delay — schedule is not mapped to "
                               "calendar dates. Set a **Schedule Start Date** in the sidebar "
                               "to define what calendar date Day 1 corresponds to."),
                "is_warning": True,
            }]
        return []

    # ── Parse the schedule start date ──────────────────────────────────────
    try:
        base_date = datetime.strptime(schedule_start_date, "%Y-%m-%d")
    except (ValueError, TypeError):
        return [{
            "task":       "—",
            "finish":     "—",
            "due_date":   "—",
            "status":     f"Invalid schedule start date format: '{schedule_start_date}'. "
                          "Expected YYYY-MM-DD.",
            "is_warning": True,
        }]

    # ── Convert days → calendar dates and compute delay ────────────────────
    results = []
    for _, row in df.iterrows():
        raw_date = str(row.get("Delivery_Date", "")).strip()
        if not raw_date or raw_date.lower() in ("", "none", "nan", "nat"):
            continue

        # Parse delivery due date
        delivery_dt = None
        for fmt in date_formats:
            try:
                delivery_dt = datetime.strptime(raw_date, fmt)
                break
            except (ValueError, TypeError):
                continue

        if delivery_dt is None:
            continue

        # Convert schedule Day N → actual calendar date
        finish_day  = int(row.get("Finish", 0))
        finish_date = base_date + timedelta(days=finish_day - 1)

        delay_days = (finish_date - delivery_dt).days

        finish_date_str = finish_date.strftime("%d-%b-%Y")

        if delay_days > 0:
            status = f"{delay_days} day(s) late"
        elif delay_days == 0:
            status = "On time (exact match)"
        elif delay_days >= -2:
            status = f"{abs(delay_days)} day(s) early (tight margin)"
        else:
            status = f"{abs(delay_days)} day(s) early"

        results.append({
            "task":            row.get("Task", "?"),
            "finish":          finish_day,
            "finish_date_str": finish_date_str,
            "due_date":        raw_date,
            "status":          status,
            "is_warning":      False,
        })

    return results
