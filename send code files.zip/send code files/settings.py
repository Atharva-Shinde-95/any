# config/settings.py
import os
import sys
from dotenv import load_dotenv

load_dotenv()

# ── Capgemini Generative Engine ────────────────────────────────────────────────
# Consumed by config/llm.py — agents do NOT import these directly.
# They call get_llm() instead.
GENERATIVE_ENGINE_API_KEY  = os.getenv("GENERATIVE_ENGINE_API_KEY", "")
GENERATIVE_ENGINE_BASE_URL = os.getenv(
    "GENERATIVE_ENGINE_BASE_URL",
    "https://api.generative.engine.capgemini.com"
)
GENERATIVE_ENGINE_MODEL    = os.getenv(
    "GENERATIVE_ENGINE_MODEL",
    "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
)

# ── MCP Server commands ────────────────────────────────────────────────────────
_PYTHON  = sys.executable
_MCP_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "mcp_servers"))

FILE_PROCESSING_MCP_CMD  = [_PYTHON, os.path.join(_MCP_DIR, "file_processing_server.py")]
DATA_ANALYSIS_MCP_CMD    = [_PYTHON, os.path.join(_MCP_DIR, "data_analysis_server.py")]
PLANNING_MCP_CMD         = [_PYTHON, os.path.join(_MCP_DIR, "planning_server.py")]
SCHEDULING_MCP_CMD       = [_PYTHON, os.path.join(_MCP_DIR, "scheduling_server.py")]
VISUALISATION_MCP_CMD    = [_PYTHON, os.path.join(_MCP_DIR, "visualisation_server.py")]

# ── OR-Tools solver ────────────────────────────────────────────────────────────
SOLVER_TIME_LIMIT_SEC = int(os.getenv("SOLVER_TIME_LIMIT_SEC", "30"))

# ── Output ─────────────────────────────────────────────────────────────────────
OUTPUT_DIR = os.getenv("OUTPUT_DIR", "./outputs")

# ── Finite-capacity scheduler ──────────────────────────────────────────────────
DAILY_CAPACITY_UNITS = int(os.getenv("DAILY_CAPACITY_UNITS", "2000"))
