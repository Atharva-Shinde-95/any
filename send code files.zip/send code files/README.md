# 🏭 Production Planning & Scheduling Assistant

An autonomous multi-agent system for production planning, demand analysis, finite-capacity scheduling, and Gantt chart generation. Built with LangGraph, FastMCP, OR-Tools, and the Capgemini Generative Engine (Claude Sonnet).

---

## Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [File Structure](#file-structure)
- [Agent Pipeline](#agent-pipeline)
- [MCP Servers](#mcp-servers)
- [Setup & Installation](#setup--installation)
- [Running the App](#running-the-app)
- [Input Data Format](#input-data-format)
- [Example Queries](#example-queries)
- [Configuration Reference](#configuration-reference)
- [Technical Notes](#technical-notes)

---

## Overview

Upload any Excel or CSV file containing production demand data and ask questions in natural language. The system autonomously runs a full planning pipeline:

1. **Ingests** the file, detects column semantics, and cleans the data
2. **Analyses** demand by product and period, computes capacity utilisation
3. **Checks feasibility** — simulates the schedule before running the solver, flags tasks at risk of missing their deadlines
4. **Schedules** production using a priority-based finite-capacity heuristic (single line) or the OR-Tools CP-SAT exact solver (multi-resource)
5. **Reports** — generates a Markdown schedule table, a Plotly Gantt chart (interactive HTML), and planner insights

The supervisor is a fully agentic ReAct (Reason + Act) loop: it reads the current pipeline state, reasons about what to do next, and routes to the appropriate agent — it never blindly follows a fixed script.

---

## Architecture

```
User (Streamlit UI or CLI)
        │
        ▼
┌───────────────────────────────────────────────────────┐
│                  LangGraph Graph                       │
│                                                        │
│   ┌────────────┐     conditional edges                 │
│   │ supervisor │─────────────────────────────────┐    │
│   │  (ReAct)   │◄────────────────────────────────┘    │
│   └────────────┘                                       │
│         │ routes to one of:                            │
│         ▼                                              │
│   ┌─────────┐  ┌──────────┐  ┌──────────┐             │
│   │  ingest │  │ analyse  │  │  plan    │             │
│   │  agent  │  │  agent   │  │  agent   │             │
│   └────┬────┘  └────┬─────┘  └────┬─────┘            │
│        │            │             │                    │
│   ┌────┴────────────┴─────────────┴────────────┐      │
│   │              MCP Servers (stdio)            │      │
│   │  file_processing │ data_analysis │ planning │      │
│   │  scheduling      │ visualisation            │      │
│   └─────────────────────────────────────────────┘     │
│                                                        │
│   ┌──────────┐  ┌────────────┐                        │
│   │ schedule │  │   report   │──► Gantt HTML + Table  │
│   │  agent   │  │   agent    │                        │
│   └──────────┘  └────────────┘                        │
└───────────────────────────────────────────────────────┘
        │
        ▼
  LLM: Capgemini Generative Engine
  (Claude Sonnet via config/llm.py)
```

### Key design principles

- **Tool-use consistency** — every agent calls MCP tools for computation; the LLM only reasons and formats. No agent embeds raw business logic.
- **ReAct supervisor** — routes based on current state, not a hardcoded pipeline. Can skip steps, recover from errors, and answer questions without re-running the full pipeline.
- **Zero hallucination on numbers** — all scheduling facts (makespan, priorities, dates) are computed by Python/OR-Tools and passed to the LLM as pre-computed facts to format.
- **Finite-capacity aware** — every duration is `ceil(quantity / daily_capacity)`, never just the raw row value.

---

## File Structure

```
production_planner/
│
├── .env                          ← your secrets (copy from .env.example)
├── .env.example                  ← template with all required variables
├── requirements.txt
│
├── config/
│   ├── settings.py               ← all env vars, MCP server commands
│   └── llm.py                    ← Capgemini LLM wrapper (drop-in for ChatOllama)
│
├── graph/
│   ├── state.py                  ← PlanningState TypedDict (shared data contract)
│   └── planning_graph.py         ← LangGraph graph definition & compilation
│
├── agents/
│   ├── supervisor.py             ← ReAct loop: reasons + routes each turn
│   ├── ingest_agent.py           ← reads file, 2-pass schema inference (heuristic + LLM)
│   ├── analysis_agent.py         ← demand summary, capacity, task builder, start date
│   ├── planning_agent.py         ← feasibility check via MCP + LLM planning rationale
│   ├── scheduling_agent.py       ← LLM chooses scheduler; runs priority or CP-SAT
│   └── report_agent.py           ← Markdown table, Plotly Gantt, planner insights
│
├── mcp_servers/
│   ├── file_processing_server.py ← read_file, infer_column_schema, validate_and_clean_data
│   ├── data_analysis_server.py   ← compute_demand_summary, capacity_utilisation, detect_peaks
│   ├── planning_server.py        ← run_feasibility_check, summarise_at_risk_tasks
│   ├── scheduling_server.py      ← build_cp_sat_model, solve_schedule, extract_schedule_results
│   └── visualisation_server.py   ← format_schedule_table, generate_gantt_chart, get_critical_path
│
├── chatbot/
│   ├── app.py                    ← Streamlit web UI
│   └── cli.py                    ← terminal fallback interface
│
└── outputs/                      ← auto-created; Gantt HTML saved here
```

---

## Agent Pipeline

Each agent runs as a LangGraph node. The supervisor decides the order dynamically using ReAct reasoning. In the typical happy path:

```
supervisor → ingest → supervisor → analyse → supervisor → plan → supervisor → schedule → supervisor → report → END
```

### supervisor
- Reads the full `PlanningState` on every call
- Sends a state summary + user query to the LLM with a strict ReAct prompt
- Parses `THOUGHT: / ACTION:` from the response
- Enforces pipeline ordering (can't run `report` before `schedule`)
- Detects and breaks action loops
- Handles `chat` (greetings), `answer` (Q&A from existing schedule), and `end` directly — no agent hop needed

### ingest_agent
- Calls `file_processing_server` → `read_file` (Excel or CSV, auto-encoding)
- Two-pass schema inference:
  1. Heuristic keyword scan (instant, always runs)
  2. LLM validation pass with sample rows (corrects unusual column names like `fcst_vol`, `deliv_dt`)
- Merges both passes; LLM wins on any key it's confident about
- Calls `validate_and_clean_data` to drop empty rows, fill numeric nulls, normalise date columns

### analysis_agent
- Selects the primary sheet by scoring columns for quantity/product/date/priority signals
- Calls `data_analysis_server` → `compute_demand_summary`, `compute_capacity_utilisation`, `flag_capacity_gaps`
- Builds the task list (name, resource, quantity, duration, deadline, priority, service_level)
- Extracts `schedule_start_date` from the earliest delivery date in the data
- LLM reviews data quality and surfaces any issues as a planner note

### planning_agent
- Calls `planning_server` → `run_feasibility_check` with the task list
  - Simulates the priority-ordered schedule (no solver, pure Python in the MCP server)
  - Computes horizon, utilisation %, and which tasks will be late or tight
- Calls `planning_server` → `summarise_at_risk_tasks` (trimmed payload for LLM)
- LLM generates a 3–5 sentence planning rationale naming specific tasks and one concrete recommendation

### scheduling_agent
- LLM examines task data and chooses: `priority` (greedy heuristic) or `cpsat` (OR-Tools solver)
- Hard override: single resource → always `priority`
- **Priority scheduler**: sorts by priority → service level → delivery date; packs tasks sequentially at `DAILY_CAPACITY_UNITS` per day; computes `Slack_Days` for each task
- **CP-SAT scheduler**: calls `scheduling_server` → `build_cp_sat_model` → `solve_schedule` → `extract_schedule_results`; minimises makespan with no-overlap per resource

### report_agent
- Generates a Markdown table with columns: Sequence, Task, Resource, Priority, Service_Level, Delivery_Date, Quantity, Start, Finish, Duration, Slack_Days
- Builds a Plotly Gantt chart as an interactive HTML file in `./outputs/`
- Computes planner insights: makespan, schedule calendar range, priority breakdown, late delivery flags

---

## MCP Servers

Each server is launched as a subprocess over `stdio` using FastMCP. They are stateless — every call is independent.

| Server | Tools |
|---|---|
| `file_processing_server` | `read_file`, `infer_column_schema`, `validate_and_clean_data`, `list_sheets` |
| `data_analysis_server` | `compute_demand_summary`, `compute_capacity_utilisation`, `detect_demand_peaks`, `flag_capacity_gaps` |
| `planning_server` | `run_feasibility_check`, `summarise_at_risk_tasks` |
| `scheduling_server` | `build_cp_sat_model`, `solve_schedule`, `extract_schedule_results`, `check_feasibility` |
| `visualisation_server` | `format_schedule_table`, `generate_gantt_chart`, `get_critical_path` |

---

## Setup & Installation

### Prerequisites

- Python 3.11+
- A Capgemini Generative Engine API key

### 1. Clone and create a virtual environment

```bash
git clone <your-repo-url>
cd production_planner
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

> **Note:** Remove `langchain-ollama==0.1.3` from `requirements.txt` — it is no longer used.

### 3. Configure environment variables

```bash
cp .env.example .env
```

Edit `.env`:

```env
# Required
GENERATIVE_ENGINE_API_KEY=your_actual_api_key_here

# Optional overrides (defaults shown)
GENERATIVE_ENGINE_BASE_URL=https://api.generative.engine.capgemini.com
GENERATIVE_ENGINE_MODEL=us.anthropic.claude-sonnet-4-5-20250929-v1:0
GENERATIVE_ENGINE_TIMEOUT=120

SOLVER_TIME_LIMIT_SEC=30
OUTPUT_DIR=./outputs
DAILY_CAPACITY_UNITS=2000
```

### 4. Create the outputs directory

```bash
mkdir -p outputs
```

---

## Running the App

### Streamlit web UI (recommended)

```bash
streamlit run chatbot/app.py
```

Opens at `http://localhost:8501`. Upload a file from the sidebar, then type a query.

### CLI (no browser required)

```bash
# Interactive mode
python chatbot/cli.py

# Load a file at startup
python chatbot/cli.py --file path/to/data.xlsx
```

### Visualise the LangGraph graph (Jupyter)

```bash
jupyter notebook plot.ipynb
```

---

## Input Data Format

The system auto-detects column semantics — no fixed schema required. It looks for columns matching these roles:

| Role | Example column names |
|---|---|
| Product / SKU | `SKU`, `Product`, `Item`, `Part`, `Material` |
| Quantity / Demand | `Qty`, `Quantity`, `Demand`, `Forecast`, `Volume` |
| Delivery date | `Deadline`, `Due Date`, `Delivery Date`, `Target` |
| Priority | `Priority`, `Urgency`, `Flag` |
| Service level | `Service Level`, `SLA` |
| Resource / Machine | `Machine`, `Resource`, `Line`, `Station` |
| Duration | `Duration`, `Hours`, `Cycle Time` |

**If no `Duration` column is present**, duration is computed as `ceil(Quantity / DAILY_CAPACITY_UNITS)`.

**Priority values recognised:** `High`, `Urgent`, `Critical`, `Normal`, `Medium`, `Low` (case-insensitive).

Both `.xlsx` and `.csv` files are supported. Multi-sheet Excel files are handled — the system picks the sheet with the richest planning data.

---

## Example Queries

```
Generate the optimized production schedule.
Show me a Gantt chart.
Which product should be produced first?
Which product is the bottleneck?
Flag any capacity gaps in the data.
How many days does the total schedule take?
Which tasks are at risk of missing their deadline?
Give me a summary of the full plan.
```

---

## Configuration Reference

All settings live in `config/settings.py` and are sourced from `.env`.

| Variable | Default | Description |
|---|---|---|
| `GENERATIVE_ENGINE_API_KEY` | *(required)* | Capgemini Generative Engine API key |
| `GENERATIVE_ENGINE_BASE_URL` | `https://api.generative.engine.capgemini.com` | Gateway base URL |
| `GENERATIVE_ENGINE_MODEL` | `us.anthropic.claude-sonnet-4-5-20250929-v1:0` | Model ID |
| `GENERATIVE_ENGINE_TIMEOUT` | `120` | HTTP timeout in seconds |
| `DAILY_CAPACITY_UNITS` | `2000` | Units the production line can produce per day |
| `SOLVER_TIME_LIMIT_SEC` | `30` | OR-Tools CP-SAT solver time limit |
| `OUTPUT_DIR` | `./outputs` | Directory for saved Gantt HTML files |

---

## Technical Notes

### LLM wrapper (`config/llm.py`)

`CapgeminiLLM` is a thin `httpx` wrapper that converts LangChain `SystemMessage` / `HumanMessage` objects to OpenAI-compatible chat-completions format and returns an `LLMResponse` with a `.content` attribute — identical interface to `ChatOllama`. All agents call `get_llm()` from this module; switching providers in future requires editing only this one file.

### Scheduler selection

The LLM examines task data (number of tasks, distinct resources, whether deadlines exist, priority levels) and chooses between:
- **Priority heuristic** (`PRIORITY-SEQUENCED`) — always used for single-resource problems; fast and predictable
- **CP-SAT solver** (`OPTIMAL` / `FEASIBLE`) — used for multi-resource problems; proves mathematical optimality within the time limit

### Slack days

`Slack_Days = due_date_as_day - finish_day`. Positive means the task finishes early; negative means it will be late. Tasks are never artificially delayed to reduce slack — an idle factory is economically worse than producing early.

### Feasibility check

The `planning_agent` runs before the scheduler. It simulates the priority-ordered schedule using only Python (via the `planning_server` MCP tool) and computes horizon utilisation and per-task lateness. This catches infeasible plans before the solver runs and gives the LLM concrete data to reason about.
