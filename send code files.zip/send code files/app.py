# chatbot/app.py
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import asyncio
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

import streamlit as st
import tempfile
from langchain_core.messages import HumanMessage
from graph.planning_graph import planning_graph
from graph.state import PlanningState
from config.settings import DAILY_CAPACITY_UNITS

st.set_page_config(page_title="Production Planner", layout="wide", page_icon="🏭")

st.title("🏭 Production Planning & Scheduling Assistant")
st.caption("Upload a forecast / production Excel or CSV file and ask questions in natural language.")

# ── Session state initialisation ──────────────────────────────────────────────
_EMPTY_STATE = dict(
    messages=[], user_query="", file_path=None, file_type=None,
    raw_sheets=None, data_schema=None, demand_summary=None,
    capacity_summary=None, capacity_gaps=None, tasks=None,
    feasibility_report=None, planning_rationale=None,
    schedule_df=None, makespan=None, solver_status=None,
    scheduler_reasoning=None,
    table_str=None, gantt_path=None, insights=None,
    llm_answer=None, next_agent=None, error=None,
    agent_scratchpad=None,
    schedule_start_date=None,
)
if "messages" not in st.session_state:
    st.session_state.messages = []
if "planning_state" not in st.session_state:
    st.session_state.planning_state = PlanningState(**_EMPTY_STATE)

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.header("📂 Data Upload")
    uploaded = st.file_uploader(
        "Upload forecast / production data",
        type=["xlsx", "xls", "csv"],
        help="Any Excel or CSV file — column names are detected automatically.",
    )
    if uploaded:
        if st.session_state.get("_uploaded_name") != uploaded.name:
            suffix = "." + uploaded.name.split(".")[-1]
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as f:
                f.write(uploaded.read())
                tmp_path = f.name
            st.session_state["_uploaded_name"] = uploaded.name
            st.session_state["_uploaded_path"] = tmp_path
            st.session_state.planning_state = PlanningState(
                **{**_EMPTY_STATE,
                   "file_path": tmp_path,
                   "file_type": "csv" if suffix == ".csv" else "excel"}
            )
            st.session_state.messages = []
        st.success(f"✅ File ready: **{uploaded.name}**")

    st.divider()
    st.subheader("⚙️ Scheduler Settings")
    st.caption(f"Daily capacity: **{DAILY_CAPACITY_UNITS:,} units/day** (set via .env)")

    # Schedule start date is now derived from the data by the analysis agent.
    # Show it here once it has been extracted (read-only — no longer hardcoded).
    derived_start = st.session_state.planning_state.get("schedule_start_date")
    if derived_start:
        st.info(f"📅 Schedule start date: **{derived_start}**\n\n"
                "_Derived from earliest delivery date in your data._")

    st.divider()
    st.subheader("💡 Example Queries")
    examples = [
        "Generate the optimized production schedule.",
        "Show me a Gantt chart with each unit timeline.",
        "Which product should be produced first?",
        "Which product is the bottleneck?",
        "Flag any capacity gaps in the data.",
        "How many days does the total schedule take?",
    ]
    for ex in examples:
        if st.button(ex, use_container_width=True):
            st.session_state["prefill_query"] = ex

    st.divider()
    if st.button("🔄 Reset Session", use_container_width=True):
        st.session_state.messages = []
        st.session_state.planning_state = PlanningState(**_EMPTY_STATE)
        st.rerun()

# ── Chat history ──────────────────────────────────────────────────────────────
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

prefill = st.session_state.pop("prefill_query", None)
prompt  = st.chat_input("Ask about the production schedule...", key="chat_input")
if prefill and not prompt:
    prompt = prefill

if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    state = st.session_state.planning_state
    state["user_query"]       = prompt
    state["agent_scratchpad"] = []     # Reset scratchpad each user turn
    state["messages"].append(HumanMessage(content=prompt))
    state["error"]      = None
    state["llm_answer"] = None

    with st.spinner("🤖 Agent reasoning..."):
        try:
            result = planning_graph.invoke(state, {"recursion_limit": 50})
            st.session_state.planning_state = result
        except Exception as e:
            import traceback
            traceback.print_exc()
            result = {**state, "error": str(e)}
            st.session_state.planning_state = result

    # ── Build reply ────────────────────────────────────────────────────────────
    reply_parts = []

    # Show agent reasoning trace (collapsible)
    scratchpad = result.get("agent_scratchpad") or []
    if scratchpad:
        trace_lines = []
        for i, step in enumerate(scratchpad, 1):
            trace_lines.append(f"**Step {i}** → `{step['action']}`")
            trace_lines.append(f"*{step['thought']}*")
        reply_parts.append(
            "<details><summary>🧠 Agent reasoning trace</summary>\n\n"
            + "\n\n".join(trace_lines)
            + "\n\n</details>"
        )

    if result.get("error"):
        reply_parts.append(f"⚠️ **Error:** {result['error']}")

    if result.get("llm_answer"):
        reply_parts.append(result["llm_answer"])

    else:
        if result.get("demand_summary"):
            reply_parts.append("📊 **Demand analysis complete.**")

        # ── Planning rationale (collapsible) ──────────────────────────────────
        planning_rationale  = result.get("planning_rationale")
        feasibility_report  = result.get("feasibility_report")
        if planning_rationale or feasibility_report:
            plan_lines = []

            if feasibility_report:
                util    = feasibility_report.get("utilisation_pct", "?")
                ok      = feasibility_report.get("overall_feasible", True)
                horizon = feasibility_report.get("horizon_days", "?")
                prod    = feasibility_report.get("total_prod_days", "?")
                demand  = feasibility_report.get("total_demand_units", 0)
                at_risk = feasibility_report.get("tasks_at_risk", [])
                sdate   = feasibility_report.get("start_date", "not set")

                feasibility_icon  = "✅" if ok else "❌"
                feasibility_label = "Feasible" if ok else "NOT Feasible"
                plan_lines.append(
                    f"**{feasibility_icon} {feasibility_label}** — "
                    f"{prod} production days needed / {horizon} days available "
                    f"({util}% utilisation) | Start: `{sdate}`"
                )

                if at_risk:
                    plan_lines.append("\n**⚠️ Tasks at risk of missing deadline:**")
                    for t in at_risk:
                        slack_str = (f"{t['slack_days']} days late"
                                     if t["slack_days"] is not None and t["slack_days"] < 0
                                     else f"{abs(t['slack_days'])} day buffer" if t["slack_days"] is not None
                                     else "no deadline")
                        icon = "🔴" if t["status"] == "late" else "🟡"
                        plan_lines.append(
                            f"{icon} **{t['name']}** — finishes Day {t['finish_day']}, "
                            f"due Day {t['due_day']} ({slack_str})"
                        )
                else:
                    plan_lines.append("✅ All tasks projected to meet their delivery deadlines.")

            if planning_rationale:
                plan_lines.append(f"\n**💡 Planning Rationale:**\n_{planning_rationale}_")

            reply_parts.append(
                "<details><summary>📋 Planning & Feasibility Report</summary>\n\n"
                + "\n\n".join(plan_lines)
                + "\n\n</details>"
            )

        if result.get("capacity_gaps"):
            alerts = [g for g in result["capacity_gaps"] if g["flag"] != "OK"]
            if alerts:
                reply_parts.append("📊 **Capacity Status:**")
                for g in alerts:
                    if g["flag"] == "OVERLOADED":
                        icon, label = "🔴", "OVERLOADED"
                    elif g["flag"] == "AT_CAPACITY":
                        icon, label = "🔵", "Fully utilised"
                    else:
                        icon, label = "🟡", "High load"
                    reply_parts.append(f"{icon} **{g['resource']}**: {g['utilisation']}% — *{label}*")
            else:
                reply_parts.append("✅ All resources within capacity limits.")

        if result.get("solver_status"):
            status = result["solver_status"]
            if status == "PRIORITY-SEQUENCED":
                status_icon  = "✅"
                status_label = "**Scheduler:** PRIORITY-SEQUENCED _(heuristic — good feasible solution)_"
            elif status == "OPTIMAL":
                status_icon  = "✅"
                status_label = "**Solver Status:** OPTIMAL _(CP-SAT proven)_"
            elif status == "FEASIBLE":
                status_icon  = "🟡"
                status_label = "**Solver Status:** FEASIBLE _(CP-SAT feasible, not proven optimal)_"
            else:
                status_icon  = "❌"
                status_label = f"**Solver Status:** {status}"

            reply_parts.append(
                f"{status_icon} {status_label} "
                f"| **Makespan:** {result.get('makespan', 'N/A')} days"
            )

        # Show LLM's scheduler reasoning
        if result.get("scheduler_reasoning"):
            reply_parts.append(
                f"💡 **Scheduler reasoning:** _{result['scheduler_reasoning']}_"
            )

        if result.get("schedule_df") is not None:
            reply_parts.append(
                "🔧 **Scheduling assumptions:**\n"
                f"- Daily production capacity: **{DAILY_CAPACITY_UNITS:,} units/day**\n"
                "- Sequencing: **High priority → Higher service level → Earliest delivery date**\n"
                "- Finite capacity, sequential (single production line)"
            )

        if result.get("table_str"):
            reply_parts.append("\n**📋 Production Schedule (Priority-Sequenced):**\n")
            reply_parts.append(result["table_str"])

        if result.get("insights"):
            reply_parts.append("\n**📊 Planner Insights:**\n")
            reply_parts.append(result["insights"])

        if not reply_parts:
            reply_parts.append("Processing complete. Ask me to generate the schedule or a Gantt chart.")

    reply = "\n\n".join(reply_parts)
    st.session_state.messages.append({"role": "assistant", "content": reply})
    with st.chat_message("assistant"):
        st.markdown(reply, unsafe_allow_html=True)

    st.rerun()

# ── Gantt chart ────────────────────────────────────────────────────────────────
gantt_path = st.session_state.planning_state.get("gantt_path")
if gantt_path and os.path.exists(gantt_path):
    st.divider()
    st.subheader("📈 Production Schedule — Gantt Chart")
    with open(gantt_path, "r", encoding="utf-8") as f:
        html_content = f.read()
    inject = (
        "<style>html, body { margin:0; padding:0; overflow-x:hidden; }"
        ".plotly-graph-div { width:100% !important; }"
        ".js-plotly-plot { width:100% !important; }</style>"
    )
    html_content = html_content.replace("</head>", inject + "</head>", 1)
    schedule_df  = st.session_state.planning_state.get("schedule_df")
    n_skus       = len(schedule_df) if schedule_df is not None else 6
    chart_height = max(450, n_skus * 65 + 220)
    st.components.v1.html(html_content, height=chart_height, scrolling=False)
    with open(gantt_path, "rb") as f:
        st.download_button(
            label="⬇️ Download Gantt Chart (HTML)",
            data=f,
            file_name="production_gantt.html",
            mime="text/html",
        )
