# config/llm.py
"""
Capgemini Generative Engine LLM wrapper.

Drop-in replacement for ChatOllama.  Every agent calls:

    from config.llm import get_llm
    llm = get_llm()
    resp = llm.invoke([SystemMessage(...), HumanMessage(...)])
    text = resp.content

The wrapper speaks OpenAI-compatible chat-completions format, which is what
the Capgemini Generative Engine gateway uses to proxy Bedrock / Anthropic models.

Environment variables (.env):
    GENERATIVE_ENGINE_API_KEY   — required, your studio API key
    GENERATIVE_ENGINE_BASE_URL  — base URL  (default shown below)
    GENERATIVE_ENGINE_MODEL     — model ID   (default shown below)
    GENERATIVE_ENGINE_TIMEOUT   — HTTP timeout in seconds (default 120)
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

import httpx
from dotenv import load_dotenv
from langchain_core.messages import BaseMessage, SystemMessage, HumanMessage, AIMessage

load_dotenv()

# ── Defaults (all overridable via .env) ────────────────────────────────────────
_DEFAULT_BASE_URL = "https://openai.generative.engine.capgemini.com/v1"
_DEFAULT_MODEL    = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
_DEFAULT_TIMEOUT  = 120   # seconds — LLM calls can be slow on large prompts


# ── Lightweight response object (mirrors ChatOllama's AIMessage) ──────────────
@dataclass
class LLMResponse:
    """Minimal response wrapper so `.content` works exactly like ChatOllama."""
    content: str

    def __str__(self) -> str:
        return self.content


# ── Core wrapper ──────────────────────────────────────────────────────────────
class CapgeminiLLM:
    """
    Synchronous LLM client for the Capgemini Generative Engine gateway.

    Speaks OpenAI chat-completions format:
        POST {base_url}/v1/chat/completions
        Authorization: Bearer {api_key}
        Body: { model, messages: [{role, content}], temperature, ... }

    Usage (identical to ChatOllama):
        llm = CapgeminiLLM()
        resp = llm.invoke([SystemMessage(content="..."), HumanMessage(content="...")])
        print(resp.content)
    """

    def __init__(
        self,
        model: str | None = None,
        temperature: float = 0.0,
        max_tokens: int = 4096,
        timeout: int | None = None,
    ) -> None:
        self.model       = model       or os.getenv("GENERATIVE_ENGINE_MODEL",    _DEFAULT_MODEL)
        self.temperature = temperature
        self.max_tokens  = max_tokens
        self.timeout     = timeout     or int(os.getenv("GENERATIVE_ENGINE_TIMEOUT", str(_DEFAULT_TIMEOUT)))

        self._api_key  = os.getenv("GENERATIVE_ENGINE_API_KEY", "")
        self._base_url = os.getenv("GENERATIVE_ENGINE_BASE_URL", _DEFAULT_BASE_URL).rstrip("/")

        if not self._api_key:
            raise EnvironmentError(
                "GENERATIVE_ENGINE_API_KEY is not set. "
                "Add it to your .env file:\n  GENERATIVE_ENGINE_API_KEY=your_key_here"
            )

    # ── Message conversion ────────────────────────────────────────────────────

    @staticmethod
    def _to_openai_messages(messages: list[BaseMessage | dict]) -> list[dict]:
        """Convert LangChain message objects → OpenAI role/content dicts."""
        role_map = {
            SystemMessage: "system",
            HumanMessage:  "user",
            AIMessage:     "assistant",
        }
        result = []
        for msg in messages:
            if isinstance(msg, dict):
                # Already in OpenAI format — pass through
                result.append(msg)
            elif isinstance(msg, BaseMessage):
                role = role_map.get(type(msg), "user")
                result.append({"role": role, "content": str(msg.content)})
            else:
                # Fallback: stringify
                result.append({"role": "user", "content": str(msg)})
        return result

    # ── Main invoke ───────────────────────────────────────────────────────────

    def invoke(self, messages: list, **kwargs: Any) -> LLMResponse:
        """
        Send messages to the Capgemini Generative Engine and return the reply.

        Args:
            messages : list of LangChain message objects (SystemMessage, HumanMessage, …)
            **kwargs : extra fields forwarded to the API body (e.g. stream=False)

        Returns:
            LLMResponse with a .content string attribute.

        Raises:
            httpx.HTTPStatusError  — on non-2xx responses (message included)
            httpx.TimeoutException — if the request exceeds self.timeout seconds
        """
        # Ensure base_url does not already end with /v1 to avoid doubling
        base = self._base_url.rstrip("/")
        if base.endswith("/v1"):
            base = base[:-3]
        endpoint = f"{base}/v1/chat/completions"

        payload = {
            "model":       self.model,
            "messages":    self._to_openai_messages(messages),
            "temperature": self.temperature,
            "max_tokens":  self.max_tokens,
            **kwargs,
        }

        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type":  "application/json",
        }

        try:
            with httpx.Client(timeout=self.timeout) as client:
                response = client.post(endpoint, json=payload, headers=headers)
                response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            # Surface the API error message (e.g. quota exceeded, bad key)
            body = ""
            try:
                body = exc.response.json().get("error", {}).get("message", exc.response.text)
            except Exception:
                body = exc.response.text
            raise httpx.HTTPStatusError(
                f"Capgemini API error {exc.response.status_code}: {body}",
                request=exc.request,
                response=exc.response,
            ) from exc

        data    = response.json()
        content = data["choices"][0]["message"]["content"]
        return LLMResponse(content=content)


# ── Factory (used by every agent) ─────────────────────────────────────────────

def get_llm(temperature: float = 0.0, max_tokens: int = 4096) -> CapgeminiLLM:
    """
    Return a configured CapgeminiLLM instance.

    All agents call this instead of constructing ChatOllama directly, so
    switching the underlying provider in future only requires editing this file.

    Example:
        from config.llm import get_llm
        llm = get_llm()
    """
    return CapgeminiLLM(temperature=temperature, max_tokens=max_tokens)
