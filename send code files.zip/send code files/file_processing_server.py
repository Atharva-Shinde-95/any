import io
# mcp_servers/file_processing_server.py
import json
import sys
import os

# Allow imports from project root when run as a subprocess
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import pandas as pd
import numpy as np
from fastmcp import FastMCP
from config.llm import get_llm
from langchain_core.messages import HumanMessage, SystemMessage

mcp = FastMCP("file-processing")
llm = get_llm()


def _make_serialisable(df: pd.DataFrame) -> pd.DataFrame:
    """Convert datetime/Timestamp columns to ISO strings so json.dumps works."""
    df = df.copy()
    for col in df.columns:
        # Convert datetime-like columns to ISO-format strings
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%Y-%m-%d").where(df[col].notna(), None)
        else:
            # Handle individual Timestamp objects in object-dtype columns
            df[col] = df[col].apply(
                lambda v: v.isoformat() if isinstance(v, pd.Timestamp) else v
            )
    return df


def _json_default(obj):
    """Fallback serialiser for any remaining non-JSON types."""
    if isinstance(obj, (pd.Timestamp, np.datetime64)):
        return str(obj)
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (np.ndarray,)):
        return obj.tolist()
    return str(obj)


@mcp.tool()
def read_file(file_path: str) -> str:
    """
    Read an Excel (.xlsx/.xls) or CSV file.
    Returns JSON string: { sheet_name: [ {col: val, ...}, ... ] }
    For CSV files, uses a single key 'Sheet1'.
    Auto-detects delimiter and encoding for CSV.
    """
    if file_path.lower().endswith(".csv"):
        import chardet
        with open(file_path, "rb") as f:
            enc = chardet.detect(f.read())["encoding"] or "utf-8"
        df = pd.read_csv(file_path, encoding=enc, sep=None, engine="python")
        df = _make_serialisable(df)
        # Serialise NaN/NaT as None for valid JSON
        return json.dumps(
            {"Sheet1": df.where(pd.notnull(df), None).to_dict(orient="records")},
            default=_json_default,
        )
    else:
        xl = pd.ExcelFile(file_path)
        result = {}
        for sheet in xl.sheet_names:
            df = xl.parse(sheet)
            df = _make_serialisable(df)
            result[sheet] = df.where(pd.notnull(df), None).to_dict(orient="records")
        return json.dumps(result, default=_json_default)


def _extract_json_from_text(text: str) -> str | None:
    """Try to extract a JSON object from potentially messy LLM output."""
    text = text.strip()
    if not text:
        return None
    # Strip markdown fences if present
    if text.startswith("```"):
        parts = text.split("```")
        if len(parts) >= 2:
            text = parts[1].lstrip("json").strip()
    # Try to find a JSON object in the text
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        candidate = text[start:end + 1]
        try:
            json.loads(candidate)
            return candidate
        except json.JSONDecodeError:
            pass
    return None


def _heuristic_schema(columns: list) -> dict:
    """Fallback: infer schema from column names using keyword matching."""
    schema = {}
    col_lower = {c: c.lower().replace("_", " ") for c in columns}

    date_keywords = ["date", "week", "period", "month", "day", "time", "delivery"]
    product_keywords = ["sku", "product", "item", "part", "material", "name"]
    quantity_keywords = ["qty", "quantity", "demand", "forecast", "amount", "count", "volume", "order"]
    resource_keywords = ["machine", "resource", "station", "line", "work center", "workcenter"]
    duration_keywords = ["duration", "time", "hours", "minutes", "cycle", "setup", "processing"]
    priority_keywords = ["priority", "urgent", "flag", "importance", "level"]
    deadline_keywords = ["deadline", "due", "target"]

    mapping = {
        "date_col": date_keywords,
        "product_col": product_keywords,
        "quantity_col": quantity_keywords,
        "resource_col": resource_keywords,
        "duration_col": duration_keywords,
        "priority_col": priority_keywords,
        "deadline_col": deadline_keywords,
    }

    for role, keywords in mapping.items():
        for col, lower in col_lower.items():
            if any(kw in lower for kw in keywords):
                schema[role] = col
                break  # first match wins for each role

    return schema


@mcp.tool()
def infer_column_schema(columns: list, sample_rows: str) -> str:
    """
    Use LLM to infer semantic roles of columns.
    Returns JSON: { 'date_col': 'Week', 'product_col': 'SKU', ... }
    Only includes keys where a confident match was found.
    Falls back to heuristic matching if LLM fails.
    """
    prompt = f"""
Given these column names: {columns}
And sample data: {sample_rows}

Identify which column corresponds to each role.
Return a JSON object with ONLY the keys that match:
  date_col, product_col, quantity_col, resource_col,
  duration_col, priority_col, deadline_col

Example output: {{"date_col": "Week", "product_col": "SKU", "quantity_col": "Demand"}}
Return ONLY the JSON object. No explanation. No markdown fences.
"""
    # Try LLM up to 2 times
    for attempt in range(2):
        try:
            resp = llm.invoke([HumanMessage(content=prompt)])
            text = resp.content.strip() if resp.content else ""
            extracted = _extract_json_from_text(text)
            if extracted:
                return extracted
            print(f"[SCHEMA] LLM attempt {attempt + 1} returned non-JSON: {text[:200]!r}")
        except Exception as e:
            print(f"[SCHEMA] LLM attempt {attempt + 1} failed: {e}")

    # Fallback to heuristic
    print(f"[SCHEMA] Falling back to heuristic schema for columns: {columns}")
    return json.dumps(_heuristic_schema(columns))


@mcp.tool()
def validate_and_clean_data(data, column_schema=None) -> str:
    """
    Clean a DataFrame JSON string:
    - Drop fully empty rows
    - Fill numeric NaN with 0
    - Normalise date columns to string YYYY-MM-DD if parseable
    Returns cleaned JSON string (orient='records').
    Accepts data and schema as either JSON strings or pre-parsed objects.
    """
    # Handle MCP deserializing JSON strings into native types
    if isinstance(data, str):
        df = pd.read_json(io.StringIO(data), orient="records")
    elif isinstance(data, list):
        df = pd.DataFrame(data)
    else:
        df = pd.DataFrame()

    if isinstance(column_schema, str):
        s = json.loads(column_schema)
    elif isinstance(column_schema, dict):
        s = column_schema
    else:
        s = {}

    df.dropna(how="all", inplace=True)
    for col in df.select_dtypes(include=[np.number]).columns:
        df[col] = df[col].fillna(0)
    if s.get("date_col") and s["date_col"] in df.columns:
        try:
            df[s["date_col"]] = pd.to_datetime(df[s["date_col"]]).dt.strftime("%Y-%m-%d")
        except Exception:
            pass
    return df.to_json(orient="records")


@mcp.tool()
def list_sheets(file_path: str) -> str:
    """Return sheet names from an Excel file without loading data."""
    if file_path.lower().endswith(".csv"):
        return json.dumps(["Sheet1"])
    xl = pd.ExcelFile(file_path)
    return json.dumps(xl.sheet_names)


if __name__ == "__main__":
    mcp.run(transport="stdio")
